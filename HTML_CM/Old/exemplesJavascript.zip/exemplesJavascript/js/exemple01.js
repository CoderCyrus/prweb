
alert("Bonjour !");
console.log("Texte d'essai");

function changeText(){
	document.getElementById('boldStuff').innerHTML = 'ECN';
}


