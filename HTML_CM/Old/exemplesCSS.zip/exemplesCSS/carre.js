function carre() {
   var resultat = document.formulaire.saisie.value * document.formulaire.saisie.value;
   alert("Le carr&eacute; de " + document.formulaire.saisie.value + " = " + resultat);
   }